rem start spimidiarpeggiator_polywin32.exe "Q49" "Out To MIDI Yoke:  1" 1 240 "THOR" 600 300 700 500 220 1 0 0 12 0 255 255 0
start spimidiarpeggiator_polywin32.exe "Q49" "loopMIDI Port 1" 0 60 "THOR" 0 50 300 900 220 1 0 0 12 0 0 100 0 mywinclass mywintitle "" ""
rem start spimidiarpeggiator_polywin32.exe "Q49" "loopMIDI Port 2" 0 120 "THOR" 300 50 300 900 220 1 0 0 12 100 0 0 0 mywinclass mywintitle "" ""
rem start spimidiarpeggiator_polywin32.exe "Q49" "loopMIDI Port 3" 0 120 "THOR" 600 50 300 900 220 1 0 0 12 100 0 0 0 mywinclass mywintitle "" ""
rem start spimidiarpeggiator_polywin32.exe "Q49" "loopMIDI Port 4" 0 120 "THOR" 900 50 300 900 220 1 0 0 12 100 0 0 0 mywinclass mywintitle "" ""
